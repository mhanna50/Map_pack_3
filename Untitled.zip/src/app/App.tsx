import { FlowChart } from "./components/FlowChart";

export default function App() {
  return (
    <div className="size-full flex items-center justify-center">
      <FlowChart />
    </div>
  );
}