import { motion } from 'motion/react';

interface Node {
  id: string;
  label: string;
  x: number;
  y: number;
}

interface Connection {
  from: string;
  to: string;
}

export function FlowChart() {
  // Define flowchart nodes - top to bottom layout
  const nodes: Node[] = [
    { id: '1', label: 'Your Google Business Profile', x: 400, y: 50 },
    
    // Level 2 - two branches
    { id: '2', label: 'Review Automation', x: 250, y: 180 },
    { id: '5', label: 'Automated Posting', x: 550, y: 180 },
    
    // Level 3
    { id: '3', label: 'More 5 Star Reviews', x: 250, y: 310 },
    { id: '6', label: 'Consistent Profile Activity', x: 550, y: 310 },
    
    // Level 4
    { id: '4', label: 'Stronger Reputation', x: 250, y: 440 },
    { id: '7', label: 'Higher Local Visibility', x: 550, y: 440 },
    
    // Convergence point
    { id: '8', label: 'More Profile Interactions', x: 400, y: 570 },
  ];

  const connections: Connection[] = [
    // Left branch
    { from: '1', to: '2' },
    { from: '2', to: '3' },
    { from: '3', to: '4' },
    { from: '4', to: '8' },
    
    // Right branch
    { from: '1', to: '5' },
    { from: '5', to: '6' },
    { from: '6', to: '7' },
    { from: '7', to: '8' },
  ];

  // Dark greenish blue color
  const primaryColor = '#3B82F6'; // blue-500

  // Helper function to get node position
  const getNodePosition = (id: string) => {
    const node = nodes.find((n) => n.id === id);
    return node ? { x: node.x, y: node.y } : { x: 0, y: 0 };
  };

  // Calculate connection path (top to bottom)
  const getConnectionPath = (from: string, to: string) => {
    const fromPos = getNodePosition(from);
    const toPos = getNodePosition(to);
    
    const startX = fromPos.x;
    const startY = fromPos.y + 30; // Bottom of node (reduced from 40)
    const endX = toPos.x;
    const endY = toPos.y - 30; // Top of node (reduced from 40)
    
    const midY = (startY + endY) / 2;
    
    return `M ${startX} ${startY} L ${startX} ${midY} L ${endX} ${midY} L ${endX} ${endY}`;
  };

  // Create rounded rectangle path that starts from top center
  const getNodeBorderPath = (x: number, y: number, width: number, height: number, radius: number) => {
    const hw = width / 2;
    const hh = height / 2;
    // Start from top center and go clockwise
    return `
      M ${x} ${y - hh + radius}
      L ${x} ${y - hh}
      L ${x} ${y - hh}
      A ${radius} ${radius} 0 0 1 ${x + radius} ${y - hh}
      L ${x + hw - radius} ${y - hh}
      A ${radius} ${radius} 0 0 1 ${x + hw} ${y - hh + radius}
      L ${x + hw} ${y + hh - radius}
      A ${radius} ${radius} 0 0 1 ${x + hw - radius} ${y + hh}
      L ${x - hw + radius} ${y + hh}
      A ${radius} ${radius} 0 0 1 ${x - hw} ${y + hh - radius}
      L ${x - hw} ${y - hh + radius}
      A ${radius} ${radius} 0 0 1 ${x - hw + radius} ${y - hh}
      L ${x - radius} ${y - hh}
      A ${radius} ${radius} 0 0 1 ${x} ${y - hh + radius}
    `;
  };

  // Get animation order based on distance from origin
  const getAnimationOrder = (nodeId: string) => {
    const orders: { [key: string]: number } = {
      '1': 0,
      '2': 1,
      '5': 1,
      '3': 2,
      '6': 2,
      '4': 3,
      '7': 3,
      '8': 4,
    };
    return orders[nodeId] || 0;
  };

  // Animation variants for nodes
  const nodeVariants = {
    hidden: { scale: 0, opacity: 0 },
    grey: { 
      scale: 1, 
      opacity: 1,
    },
    visible: (custom: number) => ({
      scale: 1,
      opacity: 1,
      transition: {
        delay: custom * 1.2,
        duration: 0.8,
        ease: "easeOut"
      }
    })
  };

  // Animation variants for connections
  const connectionVariants = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: (custom: number) => ({
      pathLength: 1,
      opacity: 1,
      transition: {
        delay: custom * 1.2,
        duration: 0.8,
        ease: "easeInOut"
      }
    })
  };

  // Animation variants for borders
  const borderVariants = {
    hidden: { pathLength: 0 },
    visible: (custom: number) => ({
      pathLength: 1,
      transition: {
        delay: custom * 1.2 + 0.5,
        duration: 0.8,
        ease: "easeOut"
      }
    })
  };

  return (
    <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-8 overflow-auto">
      <div className="relative" style={{ width: '800px', height: '700px' }}>
        <svg 
          width="800" 
          height="700" 
          className="absolute inset-0"
        >
          {/* Draw connections */}
          {connections.map((conn, index) => {
            const animationOrder = getAnimationOrder(conn.to);
            
            return (
              <g key={`${conn.from}-${conn.to}`}>
                {/* Grey line base */}
                <path
                  d={getConnectionPath(conn.from, conn.to)}
                  fill="none"
                  stroke="#d1d5db"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
                {/* Animated color line */}
                <motion.path
                  d={getConnectionPath(conn.from, conn.to)}
                  fill="none"
                  stroke={primaryColor}
                  strokeWidth="3"
                  variants={connectionVariants}
                  initial="hidden"
                  animate="visible"
                  custom={animationOrder}
                  strokeLinecap="round"
                />
                {/* Arrow marker */}
                <motion.circle
                  cx={getNodePosition(conn.to).x}
                  cy={getNodePosition(conn.to).y - 30}
                  r="4"
                  fill={primaryColor}
                  variants={connectionVariants}
                  initial="hidden"
                  animate="visible"
                  custom={animationOrder}
                />
              </g>
            );
          })}

          {/* Draw node borders */}
          {nodes.map((node) => {
            const animationOrder = getAnimationOrder(node.id);
            const isStartNode = node.id === '1';
            
            return (
              <g key={`border-${node.id}`}>
                {/* Animated colored border */}
                <motion.path
                  d={getNodeBorderPath(node.x, node.y, 180, 60, 12)}
                  fill="none"
                  stroke={primaryColor}
                  strokeWidth="10"
                  variants={borderVariants}
                  initial={isStartNode ? "visible" : "hidden"}
                  animate="visible"
                  custom={animationOrder}
                  strokeLinecap="round"
                />
              </g>
            );
          })}
        </svg>

        {/* Draw nodes */}
        {nodes.map((node, index) => {
          const animationOrder = getAnimationOrder(node.id);
          const isStartNode = node.id === '1';
          
          return (
            <motion.div
              key={node.id}
              className="absolute rounded-xl flex items-center justify-center cursor-pointer transition-all bg-white"
              style={{
                left: node.x - 90,
                top: node.y - 30,
                width: '180px',
                height: '60px',
              }}
              initial="hidden"
              animate={isStartNode ? "visible" : "grey"}
              variants={nodeVariants}
              custom={0}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.div 
                className="text-sm text-center px-4 relative z-10 text-white"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: isStartNode ? 0.5 : animationOrder * 1.2 + 0.5 }}
              >
                {node.label}
              </motion.div>
            </motion.div>
          );
        })}

        {/* Pulsing origin indicator */}
        <motion.div
          className="absolute w-4 h-4 rounded-full"
          style={{
            left: 400 - 8,
            top: 50 - 8,
            zIndex: 100,
            backgroundColor: primaryColor,
          }}
          animate={{
            scale: [1, 1.5, 1],
            opacity: [0.5, 0.8, 0.5],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>
    </div>
  );
}